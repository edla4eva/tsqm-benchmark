package com.tsqm.ui;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridData;

public class UIforTSQM {
	private static Text textExtension;
	private static Text text_1;
	private static Text text_2;
	private static Composite composite;
	private static Text textOutput;
	
	//Constructor
	public UIforTSQM(){
		
	}

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = Display.getDefault();
		final Shell shlTsqmBencmarkTool = new Shell();
		displayUI(display,shlTsqmBencmarkTool);
	}
	
	public static void displayUI (Display display, final Shell shlTsqmBencmarkTool){
		
		shlTsqmBencmarkTool.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
			}
		});
		shlTsqmBencmarkTool.setSize(641, 343);
		shlTsqmBencmarkTool.setText("TSQM Bencmark Tool");
		shlTsqmBencmarkTool.setLayout(new FormLayout());
		
		Menu menu = new Menu(shlTsqmBencmarkTool, SWT.BAR);
		shlTsqmBencmarkTool.setMenuBar(menu);
		
		MenuItem mntmFile = new MenuItem(menu, SWT.NONE);
		mntmFile.setText("File");
		
		MenuItem mntmOptions = new MenuItem(menu, SWT.CASCADE);
		mntmOptions.setText("Options");
		
		Menu menu_1 = new Menu(mntmOptions);
		mntmOptions.setMenu(menu_1);
		
		MenuItem mntmMetrics = new MenuItem(menu_1, SWT.NONE);
		mntmMetrics.setText("Metrics");
		
		MenuItem mntmWebbasedSystems = new MenuItem(menu_1, SWT.NONE);
		mntmWebbasedSystems.setText("Web-based Systems");
		
		MenuItem mntmQualityModel = new MenuItem(menu_1, SWT.NONE);
		mntmQualityModel.setText("Quality Model");
		
		MenuItem mntmNewSubmenu = new MenuItem(menu, SWT.CASCADE);
		mntmNewSubmenu.setText("Views");
		
		Menu menu_2 = new Menu(mntmNewSubmenu);
		mntmNewSubmenu.setMenu(menu_2);
		
		MenuItem mntmConfiguration = new MenuItem(menu_2, SWT.NONE);
		mntmConfiguration.setText("Configuration");
		
		MenuItem mntmBenchmarking = new MenuItem(menu_2, SWT.NONE);
		mntmBenchmarking.setText("Benchmarking");
		
		composite = new Composite(shlTsqmBencmarkTool, SWT.NONE);
		composite.setLayout(new GridLayout(6, false));
		FormData fd_composite = new FormData();
		fd_composite.bottom = new FormAttachment(100, -129);
		fd_composite.top = new FormAttachment(0, 37);
		fd_composite.left = new FormAttachment(0, 10);
		composite.setLayoutData(fd_composite);
		
		Composite composite_1 = new Composite(shlTsqmBencmarkTool, SWT.NONE);
		fd_composite.right = new FormAttachment(composite_1, -32);
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
		new Label(composite, SWT.NONE);
		
		Button btnBrowse = new Button(composite, SWT.NONE);
		btnBrowse.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialogDisplay sn = new FileDialogDisplay();
				//textOutput.setText(sn.showFileDialog(shlTsqmBencmarkTool));
				sn.setExtensions(new String[]{"*.java;*.js;*.php;*.html;*.css;*.sql", "*"});
				textOutput.setText(textOutput.getText() + "\n" + sn.showFileDialog(shlTsqmBencmarkTool) + "\n");
				
			}
		});
		btnBrowse.setText("Browse...");
		
		text_2 = new Text(composite, SWT.BORDER);
		text_2.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
		new Label(composite, SWT.NONE);
		
		Button btnNewButton_1 = new Button(composite, SWT.NONE);
		btnNewButton_1.setText("New Button");
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));
		FormData fd_composite_1 = new FormData();
		fd_composite_1.bottom = new FormAttachment(composite, 0, SWT.BOTTOM);
		fd_composite_1.right = new FormAttachment(100, -10);
		fd_composite_1.top = new FormAttachment(0, 37);
		fd_composite_1.left = new FormAttachment(100, -294);
		composite_1.setLayoutData(fd_composite_1);
		
		List list_1 = new List(composite_1, SWT.BORDER);
		
		final List listExtensions = new List(composite_1, SWT.BORDER);
		listExtensions.setItems(new String[] {".php", ".js", ".java", ".py"});
		
		textExtension = new Text(shlTsqmBencmarkTool, SWT.BORDER);
		FormData fd_textExtension = new FormData();
		fd_textExtension.right = new FormAttachment(100, -7);
		textExtension.setLayoutData(fd_textExtension);
		
		Button btnAddExtension = new Button(shlTsqmBencmarkTool, SWT.NONE);
		btnAddExtension.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnAddExtension.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if (textExtension.getText()!="" ) listExtensions.add(textExtension.getText());
				
			}
		});
		fd_textExtension.top = new FormAttachment(btnAddExtension, 2, SWT.TOP);
		fd_textExtension.left = new FormAttachment(btnAddExtension, 6);
		FormData fd_btnAddExtension = new FormData();
		fd_btnAddExtension.left = new FormAttachment(0, 473);
		fd_btnAddExtension.right = new FormAttachment(100, -97);
		fd_btnAddExtension.top = new FormAttachment(0, 6);
		btnAddExtension.setLayoutData(fd_btnAddExtension);
		btnAddExtension.setText("Add");
		
		Composite composite_2 = new Composite(shlTsqmBencmarkTool, SWT.NONE);
		FormData fd_composite_2 = new FormData();
		fd_composite_2.bottom = new FormAttachment(composite, 119, SWT.BOTTOM);
		fd_composite_2.top = new FormAttachment(composite, 6);
		fd_composite_2.left = new FormAttachment(0, 10);
		fd_composite_2.right = new FormAttachment(0, 615);
		composite_2.setLayoutData(fd_composite_2);
		
		Group grpOutput = new Group(composite_2, SWT.NONE);
		grpOutput.setText("Output");
		grpOutput.setBounds(24, 21, 571, 82);
		
		textOutput = new Text(grpOutput, SWT.BORDER | SWT.V_SCROLL);
		textOutput.setToolTipText("Output area");
		textOutput.setBounds(46, 21, 515, 51);

		shlTsqmBencmarkTool.open();
		shlTsqmBencmarkTool.layout();
		while (!shlTsqmBencmarkTool.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	public Composite getCompositeSourceFilesBrowser() {
		return composite;
	}
}
