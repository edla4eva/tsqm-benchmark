package com.tsqm.ui;
/*******************************************************************************
 * Copyright (c) 2000, 2015 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/


/*
 * FileDialog example snippet: prompt for a file name (to save)
 *
 * For a list of all SWT example snippets see
 * http://www.eclipse.org/swt/snippets/
 */
import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;

public class FileDialogDisplay {
	private String[] _extensions = {"*.java;*.js;*.php;*.html;*.css;*.sql", "*"};
	
	//Constructor
	public FileDialogDisplay(){
		
	}
public void setExtensions(String[] extensions){
	_extensions=extensions;
}
public String showFileDialog (Shell sh) {
	//Display display = new Display ();
	//Shell shell = new Shell (display);
	//shell.open ();
	FileDialog dialog = new FileDialog (sh, SWT.OPEN);
	String [] filterNames = new String [] {"Source Codes", "All Files (*)"};
	String [] filterExtensions  = _extensions; //new String []{"*.java;*.js;*.php;*.html;*.css;*.sql", "*"};
	String filterPath = "/";
	String platform = SWT.getPlatform();
	String retVal="";
	if (platform.equals("win32")) {
		filterNames = new String [] {"Source Codes", "All Files (*)"};
		filterExtensions = _extensions; //new String [] {"*.java;*.js;*.php;*.html;*.css;*.sql", "*"};
		filterPath = "c:\\";
	}
	dialog.setFilterNames (filterNames);
	dialog.setFilterExtensions (filterExtensions);
	dialog.setFilterPath (filterPath);
	//dialog.setFileName ("myfile");
	//System.out.println ("Opened from: " + dialog.open ());
	//while (!shell.isDisposed ()) {
	//	if (!display.readAndDispatch ()) display.sleep ();
	//}
	//display.dispose ();
	retVal= dialog.open();
	return "Opened from: " + retVal;
}
} 
