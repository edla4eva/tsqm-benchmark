package com.tsqm.core.benchmarks;
import org.eclipse.core.internal.events.ResourceChangeListenerList;

import org.eclipse.core.internal.events.BuildManager;
import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

import net.sourceforge.metrics.builder.MetricsBuilder;

/*
 * The main class for TSQM Benchmark
 * Implements the benchmarking method
 */
public class TSQM {
	private boolean chkResult;
	private String strStatus;
	
	//Constructor
	public TSQM(){
		strStatus="Status:  ";
		chkResult=false;
	}
	
	/*
	 * Main method
	 */
	public void doBenchmark(){
	// Load all (wrapped) metrics tools
	//Load source codes one after the other
	//Compute metrics
	//a. Check if project build successfully
	if (check()) strStatus= strStatus + "Check successful- Prog. Built";
	}
	private boolean check(){
		/**
		 * determine if project has compilation errors
		 * 
		 * @param project
		 * @return true if project has compile errors
		 */
		
		chkResult=false;
		IProject p ;
		//p.getProject();
		MetricsBuilder metricsB = new MetricsBuilder();
		p = metricsB.getProject();
		if (metricsB.hasBeenBuilt(p)) chkResult = true;
		
		org.eclipse.core.resources.IWorkspace workspace = org.eclipse.core.resources.ResourcesPlugin.getWorkspace();
		org.eclipse.jdt.core.JavaCore.create(p);
		//workspace.
		//IJavaProject currentProject = JavaCore.create(getProject());
		//if (currentProject == null) {
		//	return null;
		//}
		
		return chkResult;
		
	}
	
	public String getStatus(){
		return strStatus;
	}
	
	private void loadSource(){
		ResourceChangeListenerList resourseL = new ResourceChangeListenerList();
		resourseL.notify();
		}
	public int getValue(){
		return (int)Math.random();
	}
	

}
