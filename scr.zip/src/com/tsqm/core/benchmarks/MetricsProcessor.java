package com.tsqm.core.benchmarks;


import net.sourceforge.metrics.core.*;
import net.sourceforge.metrics.core.sources.*;
public class MetricsProcessor {


	
	public MetricsProcessor(){
		
	}
	
	public double calcRankFctor (int metricValue){
		//TODO: Rank Algorithm
		return metricValue*0.1;
		
	}
	/*
	 * Returns the Metrics IDs
	 */
 public String[] wrapMetricsPlugin(){
	 String[] strIDs; 
	 String[] strDesc;
	MetricsPlugin mp = MetricsPlugin.getDefault();
	strIDs=mp.getMetricIds();
	strDesc = mp.getMetricDescriptions();
	return strIDs;
	}
 
 /*
	 * Returns the Metrics Descriptions
	 */
public String[] getDescriptionsFromMetricsPlugin(){
	 String[] strDesc;
	MetricsPlugin mp = MetricsPlugin.getDefault();
	strDesc = mp.getMetricDescriptions();
	return strDesc;
	}
 
 public String computeMetrics(){
	 MetricsPlugin mp = MetricsPlugin.getDefault();
	 CompilationUnitMetrics cuMetrics = new CompilationUnitMetrics();
	 cuMetrics.calculate();
	 cuMetrics.toString();
	 return cuMetrics.getName();
 }
}
