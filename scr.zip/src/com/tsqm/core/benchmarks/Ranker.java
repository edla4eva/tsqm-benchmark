package com.tsqm.core.benchmarks;

import java.util.List;

import net.sourceforge.metrics.core.ICalculator;
import net.sourceforge.metrics.core.MetricsPlugin;

public class Ranker {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double result;
		System.out.println("Ranked");
		MetricsProcessor mp = new MetricsProcessor();
		result =mp.calcRankFctor(34);
		System.out.println("Result is " + result);
		//Display
		MetricsPlugin mPlug = net.sourceforge.metrics.core.MetricsPlugin.getDefault();
		String level = mPlug.PER_METHOD;
		
			
		//List<ITSQMCalculator> calcs =mPlug.getCalculators(level);
		//System.out.println(calcs.toString());
		
		System.out.println(level);
	}

}
