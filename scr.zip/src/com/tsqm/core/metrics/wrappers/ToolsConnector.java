package com.tsqm.core.metrics.wrappers;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import net.sourceforge.metrics.*;
import net.sourceforge.metrics.core.sources.*;
import net.sourceforge.metrics.core.*;
import net.sourceforge.metrics.ui.*;
import net.sourceforge.metrics.builder.*;
import net.sourceforge.metrics.calculators.*;


public class ToolsConnector {
	private int metricCount;
	private static String tmpMetricName;

	public ToolsConnector() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		wrapMetricsPlugin();		//Metrics plugin for Eclipse (net.sourceforge.metrics)
	}
	
	//public static void wrapMetricsPlugin(){
		
		// Metric plugin provides the framework
		
		//worked
		//MetricsPlugin mpg = new MetricsPlugin();
		//System.out.println(mpg.WMC);
		
		
		//TODO
		
		//MetricDescriptor mD;
		//mD.createFrom(element);
		//mD.getHint();
		//String[] metricIDs = mpg.getMetricDescriptions();
		//System.out.println(metricIDs[0]);
		
		//NOT Working
		//String[] metricDes = mpg.getMetricDescriptions();
		//System.out.println(metricDes[0]);
		
		//MetricsBuilder mb = new MetricsBuilder();
		//System.out.println(mb.toString());
		
		//MethodMetrics m = new MethodMetrics();
		//System.out.println(m.toString());
		//m.calculate();
		
	//}
	public static void wrapMetricsPlugin(){
		//worked
		MetricsPlugin mpg = new MetricsPlugin();
		System.out.println(mpg.WMC);
		
		//MetricsPlugin.getDefault().addPropertyChangeListener(this);
		net.sourceforge.metrics.core.MetricsPlugin plugin = net.sourceforge.metrics.core.MetricsPlugin.getDefault();
		String[] names = plugin.getMetricIds();
		String[] descriptions = plugin.getMetricDescriptions();
		
		showMessage ("Name 0: " + names[0] + descriptions[1]);
	}
	private static void showMessage(String message) {
		MessageBox mb=new MessageBox(new Shell());
		mb.setMessage(message);
			mb.open();
	}
}
