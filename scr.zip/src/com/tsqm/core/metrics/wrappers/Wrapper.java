package com.tsqm.core.metrics.wrappers;


public class Wrapper {

	public Wrapper() {
		// TODO Auto-generated constructor stub
	}

}
