/**
 * 
 */
package com.tsqm.core.metrics.wrappers.sources;

import org.eclipse.jdt.core.dom.MethodDeclaration;

import net.sourceforge.metrics.core.sources.MethodMetrics;

/**
 * @author Olaye-Pav User
 *
 */
public class TSQMMethodMetrics extends MethodMetrics {

	/**
	 * 
	 */
	public TSQMMethodMetrics() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param methodDeclaration
	 */
	public TSQMMethodMetrics(MethodDeclaration methodDeclaration) {
		super(methodDeclaration);
		// TODO Auto-generated constructor stub
	}

}
