package com.tsqm.core.metrics.wrappers.sources;

import net.sourceforge.metrics.core.Log;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

public class TestStuff {
	IProject project;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		if ((!selection.isEmpty()) && (selection instanceof IStructuredSelection)) {
			try {
				// Openable op =
				// (Openable)((IStructuredSelection)selection).getFirstElement();
				IJavaElement elem = (IJavaElement) ((IStructuredSelection) selection).getFirstElement();
				if (elem != null) {
					project = (IProject) elem.getUnderlyingResource();
					//action.setChecked(project.hasNature(PLUGIN_ID + ".nature"));
				System.out.println(project.getName());
				}
			} catch (Throwable e) {
				Log.logError("EnableMetrics: error getting project.", e);
				project = null;
			}
		}
		
		System.out.println(project.getName());
	}

	
	/**
	 * react to selections elsewhere in the workbench
	 * 
	 * @see org.eclipse.ui.ISelectionListener#selectionChanged(org.eclipse.ui.IWorkbenchPart, org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		/*if (!selection.isEmpty()) {
			if (selection instanceof IStructuredSelection) {
				IStructuredSelection l_structSelection = (IStructuredSelection) selection;
				if (l_structSelection.size() == 1) { // only one element allowed
					Object l_first = (l_structSelection).getFirstElement();
					IJavaElement l_jElem = null;
					if (l_first instanceof IJavaElement) {
						l_jElem = (IJavaElement) l_first;
					} else if (l_first instanceof IResource) {
						l_jElem = (IJavaElement) ((IResource) l_first).getAdapter(IJavaElement.class);
					}
					if (l_jElem != null && canDoMetrics(l_jElem)) {
						try {
							if (l_jElem.getJavaProject().getProject().hasNature(pluginId + ".nature")) {
								setJavaElement(l_jElem, false);
							}
						} catch (CoreException l_ce) {
							// TODO GB 04/15/2005 ? what to do in such case
							Log.logError("project nature does not exist", l_ce);
						}
					}
				}
			}
		}*/
	}

}
