/**
 * 
 */
package com.tsqm.core.metrics.wrappers.sources;

import org.eclipse.jdt.core.dom.ASTNode;

import net.sourceforge.metrics.core.sources.AbstractMetricSource;
import net.sourceforge.metrics.internal.xml.IXMLExporter;

/**
 * @author Olaye-Pav User
 *
 */
public class TSQMAbstractMetricSource extends AbstractMetricSource {

	/* (non-Javadoc)
	 * @see net.sourceforge.metrics.core.sources.AbstractMetricSource#initializeChildren(net.sourceforge.metrics.core.sources.AbstractMetricSource)
	 */
	@Override
	protected void initializeChildren(AbstractMetricSource parentMetric) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see net.sourceforge.metrics.core.sources.AbstractMetricSource#getASTNode()
	 */
	@Override
	public ASTNode getASTNode() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.metrics.core.sources.AbstractMetricSource#getLevel()
	 */
	@Override
	public int getLevel() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.metrics.core.sources.AbstractMetricSource#getExporter()
	 */
	@Override
	public IXMLExporter getExporter() {
		// TODO Auto-generated method stub
		return null;
	}

}
