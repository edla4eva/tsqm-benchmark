package com.tsqm.core.metrics.wrappers.sources;

public class Test {
	public void test() {
	TSQMAbstractMetricSource ms = new TSQMAbstractMetricSource();
	ms.getASTNode();
	ms.getJavaElement();


	
	}

}
