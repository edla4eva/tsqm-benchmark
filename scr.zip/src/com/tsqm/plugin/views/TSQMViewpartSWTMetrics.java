package com.tsqm.plugin.views;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import net.sourceforge.metrics.ui.MetricsView;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionListener;

import com.tsqm.core.benchmarks.MetricsProcessor;
import com.tsqm.core.benchmarks.TSQM;
import com.tsqm.core.metrics.wrappers.ToolsConnector;
import com.tsqm.data.MySQLConnector;
import com.tsqm.data.MySQLReaderJdbc;
import com.tsqm.ui.UIforTSQM;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.TableColumn;

public class TSQMViewpartSWTMetrics extends ViewPart {
	protected final static String EOL = System.getProperty("line.separator");
	protected final static String EMPTY_STRING = "";
	public static final String ID = "com.tsqm.plugin.views.TSQMViewpartSWT"; //$NON-NLS-1$
	private Text text;
	private Text text_1;
	private Table table1;
	private Table table_1;
	//TODO: TSQMBenchmarkTable table;
	private IMemento memento;

	public TSQMViewpartSWTMetrics() {
		
	}
	/**
	 * Create contents of the view part.
	 * @param parent
	 */
	@Override
	public void createPartControl(final Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);

		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(10, 32, 55, 15);
		lblNewLabel.setText("New Label");

		text = new Text(container, SWT.BORDER);
		text.setBounds(88, 32, 76, 21);

		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(10, 69, 55, 15);
		lblNewLabel_1.setText("New Label");

		text_1 = new Text(container, SWT.BORDER);
		text_1.setBounds(88, 63, 76, 21);

		table1 = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table1.setBounds(37, 125, 289, 109);
		table1.setHeaderVisible(true);
		table1.setLinesVisible(true);

		Button btnRank = new Button(container, SWT.NONE);
		btnRank.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				double result;
				String message;
				MetricsProcessor mp = new MetricsProcessor();
				result = mp.calcRankFctor(34);
				message=("Result is " + result);
				MessageDialog.openInformation(
						parent.getShell(),
						"TSQM Benchmark Rank Result",
						message);
			}
		});
		btnRank.setBounds(89, 94, 75, 25);
		btnRank.setText("Rank");

		Button btnWrapMetrics = new Button(container, SWT.NONE);
		btnWrapMetrics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnWrapMetrics.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				com.tsqm.xml.TSQMImporter.getXML();
				showMessage("We have just done magic to phpDepend");
				/*com.tsqm.core.benchmarks.MetricsProcessor mp = new com.tsqm.core.benchmarks.MetricsProcessor();
				String[] metricsIDs;
				String[] metricsDesc;
				String strMsg="";
				metricsIDs=mp.wrapMetricsPlugin();
				metricsDesc=mp.getDescriptionsFromMetricsPlugin();
				System.out.println(metricsIDs[1]);
				//Show all the metrics plugins
				showMessage(metricsIDs[0]+ " and " + metricsIDs [1]);
				for (String element : metricsDesc) {
					//	Label l = new Label(exp, SWT.NONE);
					//	l.setText(element);
					strMsg=  strMsg + EOL + element;
				}
				strMsg = strMsg + EOL + "Metrics IDs" + EOL;
				for (String element : metricsIDs) {
					strMsg=  strMsg + EOL + element;
				}
				showMessage(strMsg);
				//showMessage(mp.computeMetrics());	
*/			}
		});
		btnWrapMetrics.setBounds(251, 94, 75, 25);
		btnWrapMetrics.setText("Wrap Metrics");

		Button btnUiShowDialog = new Button(container, SWT.NONE);
		btnUiShowDialog.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				com.tsqm.ui.FileDialogDisplay fileDlg = new com.tsqm.ui.FileDialogDisplay();
				fileDlg.showFileDialog(parent.getShell());
			}
		});
		btnUiShowDialog.setBounds(221, 252, 105, 25);
		btnUiShowDialog.setText("UI: Show Dialog");

		Button btnStartBenchmark = new Button(container, SWT.NONE);
		btnStartBenchmark.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//TSQM benchmark = new TSQM();
				//benchmark.doBenchmark();
				showMessage("Not yet implemented"); //benchmark.getStatus());

			}
		});
		btnStartBenchmark.setBounds(221, 294, 105, 25);
		btnStartBenchmark.setText("CORE: Benchmark");
/*
		table_1 = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table_1.setBounds(373, 125, 211, 109);
		table_1.setHeaderVisible(true);
		table_1.setLinesVisible(true);

		TableColumn tblclmnNewColumn = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("Metric");


		TableColumn tblclmnNewColumn_1 = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn_1.setWidth(100);
		tblclmnNewColumn_1.setText("Rank");
		
		
		TableItem rowT = new TableItem(table_1, SWT.NONE);
		rowT.setText(new String[] {"LOC", "Position"});
		
		String[] cols = new String[] { "vG", "Position"};
		TableItem rowT2 = new TableItem(table_1, SWT.NONE);
		cols[0] = "Test1";
		cols[2] = "Test1";
		rowT2.setText(cols);
		//Can we reuse?
		rowT2 = new TableItem(table_1, SWT.NONE);
	

		
			for (int i = 1; i < cols.length; i++) {
				rowT.setText(i, cols[i]);
			}
*/	

		Button btnNewButton = new Button(container, SWT.NONE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Get data from db
				text.setText("TODO");
				text_1.setText("TODO");
				//getData();
				showMessage("TODO: Not yet implemented");
				
			}
		});
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
			}
		});
		btnNewButton.setBounds(221, 349, 105, 25);
		btnNewButton.setText("DATA: Read data");
		
		Button btnGetContentFrom = new Button(container, SWT.NONE);
		btnGetContentFrom.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//IViewPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView("com.tsqm.plugin.views.TSQMViewpartSWTforSCAU");
				IViewPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(TSQMViewpartSWTforSCAU.ID);
				IViewPart part2 = (MetricsView)PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView("net.sourceforge.metrics.ui.MetricsView");
			        
				if (part instanceof TSQMViewpartSWTforSCAU) {
			        	TSQMViewpartSWTforSCAU view = (TSQMViewpartSWTforSCAU) part;
			            String text = view.getTitle();
			            text= text + " & " + view.getContent();
			            showMessage("I got this from a view: " + text);
			            
			           text= part2.getTitle();
			            showMessage("I got this from a view: " + text);
			            
			        }
			}
		});
		btnGetContentFrom.setBounds(343, 94, 143, 25);
		btnGetContentFrom.setText("Get content from View");
		
		//Composite composite = new Composite(container, SWT.NONE);
		//composite.setBounds(587, 20, 139, 99);
		//TODO: Create a table that will be populated with benchmark data
		//createTable(composite);
		createActions();
		initializeToolBar();
		initializeMenu();
	}

	private void createTable(Composite c) {
		/*table = new TSQMBenchmarkTable(c, SWT.FULL_SELECTION);
		GridData data = new GridData(GridData.FILL_BOTH | SWT.H_SCROLL | SWT.V_SCROLL);
		data.grabExcessHorizontalSpace = true;
		data.grabExcessVerticalSpace = true;
		table.setLayoutData(data);
		table.initWidths(memento);
		TSQM bmRanker = new TSQM();
		table.setBenchmark(bmRanker);
		table.addSelectionListener(new SelectionListener() {

			public void widgetSelected(SelectionEvent e) {
				TreeItem item = (TreeItem) e.item;
				if (item != null) {
					supplementTitle(item);
				}
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
*/
	}
	

	/**
	 * Display a dialog box.
	 */
	private void showMessage(String message) {
		//text.getShell()
		Shell sh= new Shell();
		MessageDialog.openInformation(
				sh,
				"TSQM Benchmark",
				message);
	}
	
		/**
	 * Add the metric desciption to the titlebar
	 * 
	 * @param item
	 */
	private void supplementTitle(TreeItem item) {
		/*StringBuffer b = getTitlePrefix(selection);
		TreeItem root = item; // fix submitted by Jacob Eckel 5/27/03
		while (root.getParentItem() != null) {
			root = root.getParentItem();
		}
		b.append(" - ").append(root.getText(0));
		setPartName(b.toString());*/
	}
	
	/**
	 * Connect to database an retrieve data.
	 */
	private void getData() {
		showMessage("Data retrieval system");
		Connection cn=null;
		//TODO: Get it from preference
		String connectionUrl = "jdbc:mysql://localhost:3306/mysql";
		//MySQLConnector mysqlcn = new MySQLConnector();
		//cn=mysqlcn.connectToMySQLDB("jdbc:mysql://localhost:3306/mysql", "root", "");
		
		//new com.mysql.jdbc.Driver();
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		showMessage(e1.getMessage());
		}
		try {
			
			cn=DriverManager.getConnection(connectionUrl, "root", "");
			cn.commit();
			showMessage("Connection created and commited successfully");
			text.setText("Connection created and commited successfully");
			
			MySQLReaderJdbc myreader = new MySQLReaderJdbc();
			String[] data= myreader.readDataFromDB(cn, "select * from user");
			text_1.setText(data[0]);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage(e.getMessage());
		}
	}
	public String getContent(){
		return text.getText();
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Initialize the toolbar.
	 */
	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	/**
	 * Initialize the menu.
	 */
	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}
}
