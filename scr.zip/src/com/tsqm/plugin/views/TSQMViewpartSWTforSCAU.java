package com.tsqm.plugin.views;

import java.lang.reflect.Array;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.tsqm.plugin.TSQMPluginActivator;
import com.tsqm.plugin.preferences.PreferenceConstants;
import com.tsqm.ui.FileDialogDisplay;

import net.sourceforge.metrics.*;

import org.eclipse.swt.custom.StackLayout;

public class TSQMViewpartSWTforSCAU extends ViewPart {
	protected final static String EOL = System.getProperty("line.separator");
	protected final static String EMPTY_STRING = "";
	public static final String ID = "com.tsqm.plugin.views.TSQMViewpartSWTforSCAU"; //$NON-NLS-1$
	private Text textExtensions;
	private Text text_directory;
	private Text text_workspace;
	private Composite composite_3;
	private Button btnAddExtension;
	private Text textOutput;
	private List listExtensions;
	private FormData fd_text_directory;
	private Button buttonAnalyse;
	private Label lblExtensions;
	private Group group;
	private Button btnLoadDefaults;
	private Button button;

	public TSQMViewpartSWTforSCAU() {
	}

	/**
	 * Create contents of the view part.
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new FormLayout());
		{
			btnAddExtension = new Button(container, SWT.NONE);
			FormData fd_btnAddExtension = new FormData();
			fd_btnAddExtension.right = new FormAttachment(0, 536);
			fd_btnAddExtension.top = new FormAttachment(0, 103);
			fd_btnAddExtension.left = new FormAttachment(0, 464);
			btnAddExtension.setLayoutData(fd_btnAddExtension);
			btnAddExtension.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
				}
			});
			btnAddExtension.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {
					if (textExtensions.getText()!="" ) listExtensions.add(textExtensions.getText());

				}
			});
			btnAddExtension.setText("Add");
		}
		{
			textExtensions = new Text(container, SWT.BORDER);
			FormData fd_textExtensions = new FormData();
			fd_textExtensions.right = new FormAttachment(0, 536);
			fd_textExtensions.top = new FormAttachment(0, 59);
			fd_textExtensions.left = new FormAttachment(0, 464);
			textExtensions.setLayoutData(fd_textExtensions);
		}
		{
			listExtensions = new List(container, SWT.BORDER);
			FormData fd_listExtensions = new FormData();
			fd_listExtensions.bottom = new FormAttachment(0, 159);
			fd_listExtensions.right = new FormAttachment(0, 623);
			fd_listExtensions.top = new FormAttachment(0, 41);
			fd_listExtensions.left = new FormAttachment(0, 542);
			listExtensions.setLayoutData(fd_listExtensions);
			listExtensions.setItems(new String[] {".php", ".js", ".java", ".py"});
		}
		{
			composite_3 = new Composite(container, SWT.NONE);
			FormData fd_composite_3 = new FormData();
			fd_composite_3.bottom = new FormAttachment(0, 159);
			fd_composite_3.right = new FormAttachment(0, 437);
			fd_composite_3.top = new FormAttachment(0, 41);
			fd_composite_3.left = new FormAttachment(0, 20);
			composite_3.setLayoutData(fd_composite_3);
			composite_3.setLayout(new FormLayout());
			{
				text_directory = new Text(composite_3, SWT.BORDER);
				fd_text_directory = new FormData();
				fd_text_directory.top = new FormAttachment(0, 7);
				text_directory.setLayoutData(fd_text_directory);
			}
			{
				button = new Button(composite_3, SWT.NONE);
				fd_text_directory.right = new FormAttachment(button, -27);
				FormData fd_button = new FormData();
				fd_button.top = new FormAttachment(0, 5);
				fd_button.right = new FormAttachment(100, -10);
				button.setLayoutData(fd_button);
				button.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						com.tsqm.plugin.views.FileDialogDisplay fd = new  com.tsqm.plugin.views.FileDialogDisplay();
						fd.show();

					}
				});
				button.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
					}
				});
				button.setText("Browse...");
			}
			{
				text_workspace = new Text(composite_3, SWT.BORDER);
				FormData fd_text_workspace = new FormData();
				fd_text_workspace.left = new FormAttachment(0, 129);
				fd_text_workspace.right = new FormAttachment(100, -96);
				fd_text_workspace.top = new FormAttachment(0, 35);
				text_workspace.setLayoutData(fd_text_workspace);
			}
			{
				buttonAnalyse = new Button(composite_3, SWT.NONE);
				FormData fd_buttonAnalyse = new FormData();
				fd_buttonAnalyse.left = new FormAttachment(0, 212);
				fd_buttonAnalyse.right = new FormAttachment(100, -96);
				fd_buttonAnalyse.bottom = new FormAttachment(100, -10);
				buttonAnalyse.setLayoutData(fd_buttonAnalyse);
				buttonAnalyse.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						
						doSourceCodeAnalysis();
						showMessage("TODO: Analysis");
						
						//TODO: Test
						com.tsqm.xml.MetricsToTSQM.main();
						showMessage("PHP Tampared with");
						
						
					}
				});
				buttonAnalyse.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
					}
				});
				buttonAnalyse.setText("Analyse");
			}
		}
		{
			group = new Group(container, SWT.NONE);
			FormData fd_group = new FormData();
			fd_group.bottom = new FormAttachment(0, 283);
			fd_group.right = new FormAttachment(0, 648);
			fd_group.top = new FormAttachment(0, 165);
			fd_group.left = new FormAttachment(0, 10);
			group.setLayoutData(fd_group);
			
			Label lblParentDirectoryOf = new Label(composite_3, SWT.NONE);
			FormData fd_lblParentDirectoryOf = new FormData();
			fd_lblParentDirectoryOf.top = new FormAttachment(text_workspace, 3, SWT.TOP);
			lblParentDirectoryOf.setLayoutData(fd_lblParentDirectoryOf);
			lblParentDirectoryOf.setText("Workspace ");
			
			Label label = new Label(composite_3, SWT.NONE);
			fd_lblParentDirectoryOf.left = new FormAttachment(label, 0, SWT.LEFT);
			fd_text_directory.left = new FormAttachment(0, 219);
			label.setText("Parent Directory of Web-based System");
			FormData fd_label = new FormData();
			fd_label.top = new FormAttachment(text_directory, 3, SWT.TOP);
			fd_label.right = new FormAttachment(text_directory, -6);
			label.setLayoutData(fd_label);
			{
				btnLoadDefaults = new Button(composite_3, SWT.NONE);
				btnLoadDefaults.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						//Get the defaults from the preferences
						updateOutput( "Loaded from preference:" + getDefaultFromPreferences());
						text_workspace.setText(getDefaultFromPreferences() );
					}
				});
				btnLoadDefaults.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
					}
				});
				FormData fd_btnLoadDefaults = new FormData();
				fd_btnLoadDefaults.top = new FormAttachment(button, 6);
				fd_btnLoadDefaults.right = new FormAttachment(button, 0, SWT.RIGHT);
				btnLoadDefaults.setLayoutData(fd_btnLoadDefaults);
				btnLoadDefaults.setText("Load Defaults");
			}
			group.setText("Output");
			{
				textOutput = new Text(group, SWT.BORDER | SWT.V_SCROLL);
				textOutput.setToolTipText("Output area");
				textOutput.setBounds(10, 21, 603, 87);
			}
		}
		{
			lblExtensions = new Label(container, SWT.NONE);
			FormData fd_lblExtensions = new FormData();
			fd_lblExtensions.top = new FormAttachment(0, 20);
			fd_lblExtensions.left = new FormAttachment(0, 543);
			lblExtensions.setLayoutData(fd_lblExtensions);
			lblExtensions.setText("Extensions:");
		}
		
		Button btnRemove = new Button(container, SWT.NONE);
		FormData fd_btnRemove = new FormData();
		fd_btnRemove.right = new FormAttachment(0, 536);
		fd_btnRemove.top = new FormAttachment(0, 134);
		fd_btnRemove.left = new FormAttachment(0, 464);
		btnRemove.setLayoutData(fd_btnRemove);
		btnRemove.setText("Remove");
		
		Label lblAddToList = new Label(container, SWT.NONE);
		FormData fd_lblAddToList = new FormData();
		fd_lblAddToList.top = new FormAttachment(0, 38);
		fd_lblAddToList.left = new FormAttachment(0, 464);
		lblAddToList.setLayoutData(fd_lblAddToList);
		lblAddToList.setText("Add to list");

		createActions();
		initializeToolBar();
		initializeMenu();
	}


	private void showMessage(String message) {
		MessageDialog.openInformation(
				textExtensions.getShell(),
				"TSQM Benchmark",
				message);
	}
	
	private void updateOutput(String message) {
		textOutput.setText(message);
	}
	
	/**
	 * TSQM: Perform Source code analysis
	 */
	private void doSourceCodeAnalysis(){
		String[] ext =listExtensions.getItems();
		updateOutput ("Analysing sources with " + ext[0] + "extensions ...");

	}
	
	/**
	 * TSQM Get the default settings from already stored preferences
	 */
	private String getDefaultFromPreferences(){
		IPreferenceStore store = TSQMPluginActivator.getDefault().getPreferenceStore();	
		store.setDefault(PreferenceConstants.P_BOOLEAN, true);
		return store.getString(PreferenceConstants.P_PATH);
		//return store.getString(dPref);	//Make it generic
	}
	
	/**
	 * TSQM Get the default settings from already stored preferences
	 */
	private void storeDefaultFromPreferences(){
		IPreferenceStore store = TSQMPluginActivator.getDefault().getPreferenceStore();	
		store.setDefault(PreferenceConstants.P_BOOLEAN, true);
		//TODO
		
	}

	
	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Initialize the tool bar.
	 */
	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	/**
	 * Initialize the menu.
	 */
	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}

	public String getContent() {
		// TODO Auto-generated method stub
		return btnAddExtension.getText();
	}
}
