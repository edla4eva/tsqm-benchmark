package com.tsqm.plugin.popup.actions;

import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

public class TSQMNewAction implements IObjectActionDelegate {

	private Shell shell;
	
	/**
	 * Constructor for Action1.
	 */
	public TSQMNewAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		MessageDialog.openInformation(
			shell,
			"TSQM Benchmark Plugin",
			"TSQM Pop-up Action was executed.");
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 * TODO: TSQM I can react to selections
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		/*IJavaElement elem = (IJavaElement) ((IStructuredSelection) selection).getFirstElement();
		if (elem != null) {
			IProject project;
			try {
				project = (IProject) elem.getUnderlyingResource();
				System.out.println(project.getName());
				MessageDialog.openInformation(
						shell,
						"TSQM Benchmark Plugin",
						"TSQM noticed a change." + project.getName());
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				MessageDialog.openInformation(
						shell,
						"TSQM Benchmark Plugin",
						"iLLegal Selection" );
			}
			//action.setChecked(project.hasNature(PLUGIN_ID + ".nature"));
		
		
	}*/

	}
}
