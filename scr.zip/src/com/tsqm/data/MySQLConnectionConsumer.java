package com.tsqm.data;
import java.sql.Connection;
import java.sql.SQLException;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;


public class MySQLConnectionConsumer {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection cn=null;
		
		MySQLConnector mysqlcn = new MySQLConnector();
		cn=mysqlcn.connectToMySQLDB("jdbc:mysql://localhost:3306/mysql", "root", "");
		Shell parent = new Shell();
		String title = "DB Dialog";
		String message="Connection created and closed successfully";
		 
		try {
			cn.close();
			MessageDialog.openInformation(parent, title, message);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
