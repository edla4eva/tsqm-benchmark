package com.tsqm.data;

import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.beans.PojoObservables;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class MySQLDataBinderForm extends Composite {

	private DataBindingContext m_bindingContext;
	private org.eclipse.swt.widgets.Combo combo;
	private Text textText;

	public MySQLDataBinderForm(Composite parent, int style,
			org.eclipse.swt.widgets.Combo newCombo) {
		this(parent, style);
		setCombo(newCombo);
	}

	public MySQLDataBinderForm(Composite parent, int style) {
		super(parent, style);
		setLayout(new GridLayout(2, false));

		new Label(this, SWT.NONE).setText("Text:");

		textText = new Text(this, SWT.BORDER | SWT.SINGLE);
		textText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));

		if (combo != null) {
			m_bindingContext = initDataBindings();
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	private DataBindingContext initDataBindings() {
		IObservableValue textObserveWidget = SWTObservables.observeText(
				textText, SWT.Modify);
		IObservableValue textObserveValue = PojoObservables.observeValue(combo,
				"text");
		//
		DataBindingContext bindingContext = new DataBindingContext();
		//
		bindingContext.bindValue(textObserveWidget, textObserveValue, null,
				null);
		//
		return bindingContext;
	}

	public org.eclipse.swt.widgets.Combo getCombo() {
		return combo;
	}

	public void setCombo(org.eclipse.swt.widgets.Combo newCombo) {
		setCombo(newCombo, true);
	}

	public void setCombo(org.eclipse.swt.widgets.Combo newCombo, boolean update) {
		combo = newCombo;
		if (update) {
			if (m_bindingContext != null) {
				m_bindingContext.dispose();
				m_bindingContext = null;
			}
			if (combo != null) {
				m_bindingContext = initDataBindings();
			}
		}
	}

}
