/*****************************************************************/
package com.tsqm.data;
//Old Method
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

//import com.mysql.jdbc.Driver;

public class MySQLReaderJdbc {
	
	public MySQLReaderJdbc(){
		//TODO: Set the default connection
		
	}
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Shell parent = new Shell();
		String title = "DB Dialog";
		String message="";
		try {
			//new com.mysql.jdbc.Driver();
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			// conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdatabase?user=testuser&password=testpassword");
			String connectionUrl = "jdbc:mysql://localhost:3306/mysql";
			String connectionUser = "root";
			String connectionPassword = "";
			conn = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
			stmt = conn.createStatement();
			rs = stmt.executeQuery("SELECT * FROM user");

			while (rs.next()) {
				String host = rs.getString("Host");
				String User = rs.getString("user");
				String Password = rs.getString("password");
				System.out.println("host: " + host + ", User: " + User
						+ ", Password: " + Password);
				message=message + "\n \t" + "host: " + host + ", User: " + User
						+ ", Password: " + Password;
			}
					
			//MessageDialog.openInformation(parent, title, message);
			System.out.println(message);
			//Use the method to retrieve content from Database
			String strResult[]=readDataFromDB(connectToTSQMDatabase(), "SELECT * FROM metrics");
			MessageDialog.openInformation(parent, title, strResult[0] + "\n" + strResult[1] + "\n" + strResult[2]);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { if (stmt != null) stmt.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
	}
	
	public static String[] readDataFromDB (Connection cn, String strQuery){
		
		Statement stmt = null;
		ResultSet rs = null;
		String[] message={"", "", ""};	
		
		try {
			//TODO: Default query
			if (strQuery =="") strQuery = "SELECT * FROM metrics";
			//TODO: Default connection
			if (cn==null){
				String connectionUrl = "jdbc:mysql://localhost:3306/mysql";
				String connectionUser = "root";
				String connectionPassword = "";
				cn = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
			}
			
			
			stmt = cn.createStatement();
			rs = stmt.executeQuery(strQuery);

			while (rs.next()) {
				String id = rs.getString("metric_id");
				String metricName = rs.getString("metric");
				String metricDescription = rs.getString("metric_description");
			//Save it in an array
			
			message[0]= message[0] + "\n" + id;
			message[1]= message[1] + "\n" + metricName;
			message[2]= message[2] + "\n" + metricDescription;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return message;
		
	}
	public static Connection connectToTSQMDatabase(){
		String connectionUrl = "jdbc:mysql://localhost:3306/tsqm";
		String connectionUser = "root";
		String connectionPassword = "";
		Connection cn=null;
		try {
			cn= DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cn;
		
	}
}
