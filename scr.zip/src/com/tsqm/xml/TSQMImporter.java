package com.tsqm.xml;
import java.io.File;

import org.eclipse.core.runtime.CoreException;
import org.phpsrc.eclipse.pti.tools.phpdepend.core.PHPDepend;
import org.phpsrc.eclipse.pti.tools.phpdepend.core.model.*;


public class TSQMImporter {
	
	public static void getXML(){
		PHPDepend phpHandle = PHPDepend.getInstance();
		//phpHandle.notifyAll();
		//MetricResult mr = new MetricResult("loc", 10);
		//PHPDependModel pm;
		
		//XML file
		String path;
		String filename;
		//Create a file in the current path
		File tmp = new File("");		
		//NB: We can use a dialog box to get the path
		path = tmp.getAbsolutePath();
		filename="file.xml";
		System.out.println("The XML input file path is" + path);
		
		//Create the full filename for the XML file
		File xmlFile1 = new File(path + File.separatorChar + filename);
		//Test: File xmlFile2 = new File(path + File.separatorChar + filename2);
		
		System.out.println("The XML input filename is" + xmlFile1.getPath());

		try {
			PHPDependModel.importMetricRunSession(xmlFile1);
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//phpHandle.notifyAll();
	
	}


}
